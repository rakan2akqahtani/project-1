</div>
<script src="./js/bootstrap.bundle.min.js"></script>
<script src="./js/loader.js"></script>
<script src="./js/script.js"></script>
<script src="./js/happy.js"></script>
</body>
</html>